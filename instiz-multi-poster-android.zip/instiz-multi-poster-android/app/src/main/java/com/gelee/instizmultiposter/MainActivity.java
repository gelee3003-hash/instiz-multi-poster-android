package com.gelee.instizmultiposter;

import android.app.*;
import android.content.*;
import android.graphics.Color;
import android.os.Bundle;
import android.view.*;
import android.webkit.*;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    private EditText source, title, body;
    private WebView web;
    private final LinkedHashMap<String,String> sites = new LinkedHashMap<>();

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        sites.put("루리웹", "https://bbs.ruliweb.com/community/board/300143/write");
        sites.put("뽐뿌", "https://www.ppomppu.co.kr/zboard/write.php?id=freeboard");
        sites.put("퀘이사존", "https://quasarzone.com/bbs/qb_humor/create");
        sites.put("네이버카페", "https://cafe.naver.com/ca-fe/cafes/10298136/articles/write?menuId=56");
        buildUi();
        String shared = getIntent().getStringExtra(Intent.EXTRA_TEXT);
        if (shared != null) source.setText(shared);
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(24,24,24,24);
        TextView h = new TextView(this); h.setText("인스티즈 멀티포스터"); h.setTextSize(22); h.setTextColor(Color.BLACK); root.addView(h);
        source = field("인스티즈 글 주소 또는 HTML"); root.addView(source);
        title = field("제목"); root.addView(title);
        body = field("본문 (확인·수정 가능)"); body.setMinLines(5); body.setGravity(Gravity.TOP); root.addView(body);
        Button parse = button("내용 가져오기"); parse.setOnClickListener(v -> parseInput()); root.addView(parse);
        LinearLayout row = new LinearLayout(this); row.setOrientation(LinearLayout.HORIZONTAL);
        for (Map.Entry<String,String> e : sites.entrySet()) {
            Button x = button(e.getKey()); x.setTextSize(12); x.setOnClickListener(v -> openSite(e.getValue()));
            row.addView(x, new LinearLayout.LayoutParams(0,-2,1));
        }
        root.addView(row);
        TextView note = new TextView(this); note.setText("사이트에서 로그인 후 ‘자동 입력’을 누르세요. 등록 버튼은 직접 눌러야 합니다."); root.addView(note);
        web = new WebView(this); web.getSettings().setJavaScriptEnabled(true); web.getSettings().setDomStorageEnabled(true);
        web.setWebViewClient(new WebViewClient()); root.addView(web, new LinearLayout.LayoutParams(-1,0,1));
        Button fill = button("현재 사이트에 자동 입력"); fill.setOnClickListener(v -> autofill()); root.addView(fill);
        setContentView(root);
    }

    private EditText field(String hint) { EditText e=new EditText(this); e.setHint(hint); e.setTextSize(16); return e; }
    private Button button(String text) { Button b=new Button(this); b.setText(text); return b; }
    private void openSite(String url) { web.loadUrl(url); }

    private void parseInput() {
        String s = source.getText().toString().trim();
        if (s.startsWith("http")) {
            web.loadUrl(s);
            Toast.makeText(this,"글이 열리면 필요한 부분을 길게 눌러 복사하거나 HTML을 붙여 주세요.",Toast.LENGTH_LONG).show();
            return;
        }
        String t = s.replaceAll("(?is)<script.*?</script>", "")
                .replaceAll("(?i)<br\\s*/?>", "\\n")
                .replaceAll("(?i)</p>", "\\n")
                .replaceAll("(?s)<[^>]+>", "")
                .replace("&nbsp;", " ").replace("&gt;", ">").replace("&lt;", "<").trim();
        body.setText(t);
        Toast.makeText(this,"본문을 정리했어요. 제목을 확인해 주세요.",Toast.LENGTH_SHORT).show();
    }

    private String jsQuote(String s) {
        return "'" + s.replace("\\", "\\\\").replace("'", "\\'").replace("\r", "").replace("\n", "\\n") + "'";
    }

    private void autofill() {
        String js = "(function(){"+
          "const T="+jsQuote(title.getText().toString())+",B="+jsQuote(body.getText().toString())+";"+
          "const qs=(a)=>{for(const s of a){const e=document.querySelector(s);if(e)return e}};"+
          "const set=(e,v)=>{if(!e)return false;e.focus();if(e.isContentEditable)e.innerHTML=v.replace(/\\n/g,'<br>');else e.value=v;e.dispatchEvent(new Event('input',{bubbles:true}));e.dispatchEvent(new Event('change',{bubbles:true}));return true};"+
          "const a=set(qs(['input[name=title]','input[name=subject]','input[placeholder*=제목]','textarea[name=title]']),T);"+
          "const b=set(qs(['textarea[name=content]','textarea[name=memo]','textarea[name=body]','[contenteditable=true]','textarea']),B);"+
          "return (a?'제목 ':'')+(b?'본문':'')+' 입력 완료';})()";
        web.evaluateJavascript(js, r -> Toast.makeText(this, r.replace("\"",""), Toast.LENGTH_SHORT).show());
    }

    @Override public void onBackPressed() { if (web.canGoBack()) web.goBack(); else super.onBackPressed(); }
}
